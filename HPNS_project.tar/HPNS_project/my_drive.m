function my_drive(max_time, exp_num)
   % construct the matrix a
   alpha = 1;

   d = diag([7; 13; 5; 11; 7]) / alpha;
   r = [0,1,2,3,-1; 3,0,-2,-1,-7; 2,1,0,-2,0; 2,-1,5,0,-3; -2,-3,-1,1,0];
   a = d + r;
      
   n = length(a);
   b = rand(n, 1) - 0.5*ones(n, 1);
        
   occur_rate = ones(n, 1);
  
   %suc_num = 0;
   r = zeros(1, exp_num);
   for i = 1: exp_num
      resid_hist = async_sim(a, b, occur_rate, max_time); 
     
      %suc_num = suc_num + conv_test(resid_hist, 1e-5);  
      r(i) = resid_hist(length(resid_hist));
   end

   s = spec(a); 
   fprintf('The spectrum of  T  is %4.3f\n', s(1));
   fprintf('The spectrum of |T| is %4.3f\n', s(2));
   fprintf('The average of residuals is %e\n', sum(r)/exp_num); 

   %fprintf('The probability of convergence is %4.3f\n', suc_num/exp_num); 
end
