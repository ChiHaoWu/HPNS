function y = spec(a)
   d = diag(diag(a)); 
   r = a - d;
   t = (-1)* inv(d)*r;
   
   y = [max(abs(eig(t))), max(abs(eig(abs(t))))];
end
