function proc = process(occur_rate, max_time)
%% generate Poisson processes

%  occur_rate: the occurence rate vector for these processes

   mu = 1 ./ occur_rate;
   proc = exprnd(mu);
   m = size(proc, 1);
   n = size(proc, 2);
   while  min(proc(:, n)) < Inf
      incr = exprnd(mu);
      proc = [proc, proc(:, n) + incr]; 
      n = size(proc, 2);
      for i = 1: m
         if proc(i, n) > max_time
            proc(i, n) = Inf;
         end
      end 
   end
end
