function resid_hist = async_sim(a, b, occur_rate, max_time)

n = length(a);
x_read = zeros(n);

d = diag(a);
dinv = 1 ./ d;    % inverse of diagonal entries of matrix a
x = zeros(n,1);   % current solution

% generate n Poisson processes
proc = process(occur_rate, max_time);
time = proc(:, 1);
ptr  = ones(n, 1);

resid_hist = norm(b-a*x);
while 1 
   if min(time) == Inf
      break;
   end
   
   [m, i] = min(time); 

   r_read = b - a*x_read(:, i);   

   x(i) = dinv(i) * (r_read(i) + d(i)*x_read(i, i));
   resid_hist = [resid_hist, norm(b-a*x)];

   % update values in processes
   x_read(i, i) = x(i);
   x_read(:, i) = diag(x_read);

   % update time
   ptr(i)  = ptr(i) + 1;
   time(i) = proc(i, ptr(i));
end

end
